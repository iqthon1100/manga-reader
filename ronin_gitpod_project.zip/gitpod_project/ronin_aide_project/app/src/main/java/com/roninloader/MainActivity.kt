package com.roninloader

import android.os.Bundle
import android.widget.Button
import android.widget.Switch
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

class MainActivity : AppCompatActivity() {
    private var fridaRunning = false
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        // تهيئة الأزرار والمفاتيح
        val btnStartFrida = findViewById<Button>(R.id.btnStartFrida)
        val switchGodMode = findViewById<Switch>(R.id.switchGodMode)
        val switchInfiniteMoney = findViewById<Switch>(R.id.switchInfiniteMoney)
        val switchOneHitKill = findViewById<Switch>(R.id.switchOneHitKill)
        val switchSpeedHack = findViewById<Switch>(R.id.switchSpeedHack)
        
        // تحميل ملفات Frida
        extractAssets()
        
        // إعداد المستمعين للأحداث
        btnStartFrida.setOnClickListener {
            if (!fridaRunning) {
                startFrida()
                btnStartFrida.text = "إيقاف Frida"
                fridaRunning = true
            } else {
                stopFrida()
                btnStartFrida.text = "تشغيل Frida"
                fridaRunning = false
            }
        }
        
        switchGodMode.setOnCheckedChangeListener { _, isChecked ->
            toggleFeature("godMode", isChecked)
        }
        
        switchInfiniteMoney.setOnCheckedChangeListener { _, isChecked ->
            toggleFeature("infiniteMoney", isChecked)
        }
        
        switchOneHitKill.setOnCheckedChangeListener { _, isChecked ->
            toggleFeature("oneHitKill", isChecked)
        }
        
        switchSpeedHack.setOnCheckedChangeListener { _, isChecked ->
            toggleFeature("speedHack", isChecked)
        }
    }
    
    private fun extractAssets() {
        try {
            val outputDir = File(filesDir, "frida")
            if (!outputDir.exists()) {
                outputDir.mkdirs()
            }
            
            // إنشاء ملف نصي بسيط للتأكد من أن المجلد موجود
            val placeholderFile = File(outputDir, "placeholder.txt")
            placeholderFile.writeText("يرجى وضع ملفات frida-server و frida_script.js هنا")
            
            Toast.makeText(this, "تم إنشاء مجلد Frida بنجاح", Toast.LENGTH_SHORT).show()
        } catch (e: IOException) {
            Toast.makeText(this, "فشل في إنشاء مجلد Frida: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
    
    private fun copyFile(input: java.io.InputStream, output: File) {
        val buffer = ByteArray(1024)
        val fos = FileOutputStream(output)
        var read: Int
        
        while (input.read(buffer).also { read = it } != -1) {
            fos.write(buffer, 0, read)
        }
        
        fos.flush()
        fos.close()
        input.close()
    }
    
    private fun startFrida() {
        // تنفيذ أمر بدء تشغيل Frida باستخدام صلاحيات الروت
        try {
            val process = Runtime.getRuntime().exec("su -c ${filesDir}/frida/frida-server &")
            process.waitFor()
            Toast.makeText(this, "تم تشغيل Frida بنجاح", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "فشل في تشغيل Frida: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
    
    private fun stopFrida() {
        // إيقاف عملية Frida
        try {
            val process = Runtime.getRuntime().exec("su -c killall frida-server")
            process.waitFor()
            Toast.makeText(this, "تم إيقاف Frida بنجاح", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "فشل في إيقاف Frida: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
    
    private fun toggleFeature(featureName: String, enabled: Boolean) {
        // تفعيل أو تعطيل ميزة معينة
        Toast.makeText(this, "تم ${if (enabled) "تفعيل" else "تعطيل"} ميزة $featureName", Toast.LENGTH_SHORT).show()
        // هنا يتم إرسال الأمر إلى Frida لتفعيل أو تعطيل الميزة
    }
}
