# دليل بناء وتشغيل مشروع Ronin Loader على GitPod

## مقدمة

هذا الدليل يشرح كيفية بناء وتشغيل مشروع Ronin Loader على منصة GitPod السحابية. تم إعداد المشروع بحيث يمكن بناؤه وتشغيله بسهولة في بيئة سحابية دون الحاجة إلى تثبيت أي برامج محلياً.

## ما هو GitPod؟

GitPod هي بيئة تطوير سحابية متكاملة تتيح لك العمل على مشاريعك من أي متصفح ويب. تقوم بتوفير بيئة لينكس كاملة مع جميع الأدوات اللازمة لتطوير البرمجيات، مما يتيح لك البدء في العمل فوراً دون الحاجة إلى إعداد بيئة محلية.

## الإعدادات التي تم تنفيذها

تم إجراء التعديلات التالية على المشروع ليعمل بشكل سلس على GitPod:

1. **إضافة ملف `.gitpod.yml`**: لتكوين بيئة GitPod وتحديد المهام التي يتم تنفيذها عند بدء مساحة العمل.
2. **إضافة ملف `.gitpod.Dockerfile`**: لإنشاء صورة Docker مخصصة تحتوي على جميع المتطلبات اللازمة.
3. **تحديث ملف `app/build.gradle`**: لتوافق أندرويد 14 (API 34) وتجنب مشاكل التوافق في بيئة GitPod.
4. **إضافة سكريبت `build-helper.sh`**: لتسهيل عمليات البناء والتشغيل.

## كيفية استخدام المشروع على GitPod

### الخطوة 1: فتح المشروع على GitPod

1. قم بإنشاء حساب على [GitPod](https://gitpod.io/) إذا لم يكن لديك حساب بالفعل.
2. قم برفع المشروع إلى مستودع GitHub الخاص بك.
3. افتح المشروع على GitPod بإحدى الطرق التالية:
   - أضف `https://gitpod.io/#` قبل رابط مستودع GitHub الخاص بك.
   - استخدم زر GitPod في متصفحك (بعد تثبيت إضافة GitPod).
   - انقر على زر "Open in GitPod" إذا كان موجوداً في مستودعك.

### الخطوة 2: انتظر اكتمال الإعداد التلقائي

عند فتح المشروع لأول مرة، سيقوم GitPod تلقائياً بما يلي:

1. إنشاء بيئة العمل باستخدام الصورة المحددة في `.gitpod.Dockerfile`.
2. تثبيت Android SDK وجميع المكونات اللازمة.
3. إعداد محاكي أندرويد للاختبار.
4. تنفيذ أمر البناء الأولي للمشروع.

هذه العملية قد تستغرق بضع دقائق في المرة الأولى.

### الخطوة 3: استخدام سكريبت المساعدة للبناء والتشغيل

بعد اكتمال الإعداد، يمكنك استخدام سكريبت المساعدة لتنفيذ العمليات الشائعة:

1. افتح Terminal في GitPod.
2. قم بتنفيذ السكريبت:
   ```bash
   chmod +x build-helper.sh
   ./build-helper.sh
   ```
3. اختر العملية التي تريد تنفيذها من القائمة:
   - بناء المشروع
   - إنشاء ملف APK للتصحيح
   - إنشاء ملف APK للإصدار
   - تنظيف المشروع
   - إنشاء محاكي أندرويد
   - تشغيل المحاكي
   - تثبيت التطبيق على المحاكي
   - عرض قائمة المحاكيات المتاحة

## أوامر مفيدة

يمكنك أيضاً تنفيذ الأوامر مباشرة في Terminal:

### بناء المشروع
```bash
./gradlew build
```

### إنشاء ملف APK للتصحيح
```bash
./gradlew assembleDebug
```

### إنشاء ملف APK للإصدار
```bash
./gradlew assembleRelease
```

### تنظيف المشروع
```bash
./gradlew clean
```

### إنشاء محاكي أندرويد
```bash
echo "no" | $ANDROID_HOME/cmdline-tools/latest/bin/avdmanager create avd -n Pixel_API_34 -k "system-images;android-34;google_apis;x86_64" -d "pixel"
```

### تشغيل المحاكي
```bash
$ANDROID_HOME/emulator/emulator -avd Pixel_API_34 -no-window -no-audio -no-boot-anim
```

### تثبيت التطبيق على المحاكي
```bash
$ANDROID_HOME/platform-tools/adb install -r app/build/outputs/apk/debug/app-debug.apk
```

## حل المشاكل الشائعة

### مشكلة: فشل تثبيت Android SDK

**الحل**:
- تأكد من وجود اتصال إنترنت مستقر.
- حاول تنفيذ أمر التثبيت يدوياً:
  ```bash
  mkdir -p $ANDROID_HOME/cmdline-tools
  wget -q https://dl.google.com/android/repository/commandlinetools-linux-8512546_latest.zip -O /tmp/cmdline-tools.zip
  unzip -q /tmp/cmdline-tools.zip -d /tmp/cmdline-tools
  mv /tmp/cmdline-tools/cmdline-tools $ANDROID_HOME/cmdline-tools/latest
  yes | $ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager --licenses
  $ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0"
  ```

### مشكلة: فشل بناء المشروع

**الحل**:
- تحقق من سجلات الأخطاء لمعرفة السبب المحدد.
- جرب تنظيف المشروع أولاً:
  ```bash
  ./gradlew clean
  ```
- تأكد من تثبيت جميع التبعيات:
  ```bash
  ./gradlew --refresh-dependencies
  ```

### مشكلة: فشل تشغيل المحاكي

**الحل**:
- تأكد من إنشاء المحاكي بشكل صحيح.
- تحقق من تثبيت صورة النظام المناسبة:
  ```bash
  $ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager "system-images;android-34;google_apis;x86_64"
  ```
- استخدم خيار `-no-window` عند تشغيل المحاكي في بيئة سحابية.

## ملاحظات هامة

1. **أداء المحاكي**: قد يكون أداء المحاكي في بيئة سحابية أبطأ من المحاكي المحلي.
2. **حدود الموارد**: انتبه إلى حدود الموارد في الخطة المجانية من GitPod.
3. **الاتصال المستمر**: تحتاج إلى اتصال إنترنت مستقر عند العمل مع GitPod.
4. **حفظ العمل**: تأكد من دفع التغييرات إلى مستودع Git بانتظام لتجنب فقدان العمل.

## التعديلات التي تمت على المشروع

### تحديث ملف app/build.gradle

تم تحديث ملف `app/build.gradle` ليستهدف أندرويد 14 (API 34) وتحسين التوافق مع بيئة GitPod:

```gradle
compileSdkVersion 34
defaultConfig {
    applicationId "com.roninloader"
    minSdkVersion 21
    targetSdkVersion 34
    versionCode 1
    versionName "1.0"
    testInstrumentationRunner "androidx.test.runner.AndroidJUnitRunner"
}
```

تمت إضافة خيارات lint لتجنب مشاكل التوافق:

```gradle
lintOptions {
    checkReleaseBuilds false
    abortOnError false
}
```

## الخلاصة

باتباع هذا الدليل، يمكنك بناء وتشغيل مشروع Ronin Loader على GitPod بسهولة. تتيح لك هذه البيئة السحابية العمل على المشروع من أي جهاز متصل بالإنترنت دون الحاجة إلى إعداد بيئة تطوير محلية.
