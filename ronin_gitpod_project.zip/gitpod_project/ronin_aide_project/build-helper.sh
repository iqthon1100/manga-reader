#!/bin/bash

# سكريبت لتسهيل بناء وتشغيل المشروع على GitPod

# الألوان للإخراج
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${YELLOW}مرحباً بك في سكريبت بناء مشروع Ronin Loader على GitPod!${NC}"
echo "هذا السكريبت سيساعدك في بناء وتشغيل المشروع بسهولة."

# التحقق من وجود Android SDK
if [ ! -d "$ANDROID_HOME" ]; then
    echo -e "${RED}خطأ: لم يتم العثور على Android SDK في المسار $ANDROID_HOME${NC}"
    echo "تأكد من تثبيت Android SDK وضبط متغير البيئة ANDROID_HOME بشكل صحيح."
    exit 1
fi

# قائمة بالخيارات المتاحة
show_menu() {
    echo -e "\n${GREEN}الخيارات المتاحة:${NC}"
    echo "1. بناء المشروع (./gradlew build)"
    echo "2. إنشاء ملف APK للتصحيح (./gradlew assembleDebug)"
    echo "3. إنشاء ملف APK للإصدار (./gradlew assembleRelease)"
    echo "4. تنظيف المشروع (./gradlew clean)"
    echo "5. إنشاء محاكي أندرويد"
    echo "6. تشغيل المحاكي"
    echo "7. تثبيت التطبيق على المحاكي"
    echo "8. عرض قائمة المحاكيات المتاحة"
    echo "0. خروج"
    echo -ne "${YELLOW}اختر رقم العملية: ${NC}"
    read choice
}

# تنفيذ الخيار المحدد
execute_choice() {
    case $choice in
        1)
            echo -e "${GREEN}جاري بناء المشروع...${NC}"
            ./gradlew build
            ;;
        2)
            echo -e "${GREEN}جاري إنشاء ملف APK للتصحيح...${NC}"
            ./gradlew assembleDebug
            echo -e "${GREEN}تم إنشاء ملف APK في المسار:${NC}"
            echo "app/build/outputs/apk/debug/app-debug.apk"
            ;;
        3)
            echo -e "${GREEN}جاري إنشاء ملف APK للإصدار...${NC}"
            ./gradlew assembleRelease
            echo -e "${GREEN}تم إنشاء ملف APK في المسار:${NC}"
            echo "app/build/outputs/apk/release/app-release-unsigned.apk"
            ;;
        4)
            echo -e "${GREEN}جاري تنظيف المشروع...${NC}"
            ./gradlew clean
            ;;
        5)
            echo -e "${GREEN}جاري إنشاء محاكي أندرويد...${NC}"
            echo "no" | $ANDROID_HOME/cmdline-tools/latest/bin/avdmanager create avd -n Pixel_API_34 -k "system-images;android-34;google_apis;x86_64" -d "pixel"
            echo -e "${GREEN}تم إنشاء المحاكي بنجاح!${NC}"
            ;;
        6)
            echo -e "${GREEN}جاري تشغيل المحاكي...${NC}"
            $ANDROID_HOME/emulator/emulator -avd Pixel_API_34 -no-window -no-audio -no-boot-anim &
            echo -e "${YELLOW}تم بدء تشغيل المحاكي في الخلفية.${NC}"
            ;;
        7)
            echo -e "${GREEN}جاري تثبيت التطبيق على المحاكي...${NC}"
            $ANDROID_HOME/platform-tools/adb install -r app/build/outputs/apk/debug/app-debug.apk
            ;;
        8)
            echo -e "${GREEN}قائمة المحاكيات المتاحة:${NC}"
            $ANDROID_HOME/cmdline-tools/latest/bin/avdmanager list avd
            ;;
        0)
            echo -e "${YELLOW}شكراً لاستخدام السكريبت!${NC}"
            exit 0
            ;;
        *)
            echo -e "${RED}خيار غير صالح!${NC}"
            ;;
    esac
}

# حلقة رئيسية للسكريبت
while true; do
    show_menu
    execute_choice
    echo -e "\n${YELLOW}اضغط Enter للعودة إلى القائمة الرئيسية...${NC}"
    read
done
